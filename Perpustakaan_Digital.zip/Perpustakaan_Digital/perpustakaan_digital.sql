/*
SQLyog - Free MySQL GUI v5.0
Host - 5.6.21 : Database - perpustakaan_digital
*********************************************************************
Server version : 5.6.21
*/


create database if not exists `perpustakaan_digital`;

USE `perpustakaan_digital`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Account ID',
  `username` varchar(64) NOT NULL COMMENT 'Username',
  `password` varchar(64) NOT NULL COMMENT 'Password',
  `last_login` date DEFAULT NULL COMMENT 'Last Login',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

/*Data for the table `account` */

insert into `account` values 
(35,'johannes','johannes','2016-01-05'),
(36,'edu','edu','2016-01-06'),
(37,'anita','anita','2017-05-26'),
(38,'yosua','yosua','2016-01-06'),
(39,'anggi','anggi','2017-06-07');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category` varchar(128) DEFAULT NULL COMMENT 'Category Materi'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert into `category` values 
('Buku'),
('Majalah'),
('Jurnal'),
('Video'),
('Audio');

/*Table structure for table `log_user` */

DROP TABLE IF EXISTS `log_user`;

CREATE TABLE `log_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `account_id` int(11) DEFAULT NULL COMMENT 'Account ID',
  `last_login` date DEFAULT NULL COMMENT 'Last Login',
  `worked` varchar(128) DEFAULT NULL COMMENT 'Worked',
  PRIMARY KEY (`id`),
  KEY `FK_account` (`account_id`),
  CONSTRAINT `FK_account` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `log_user` */

/*Table structure for table `materi` */

DROP TABLE IF EXISTS `materi`;

CREATE TABLE `materi` (
  `materi_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Materi ID',
  `nama_materi` varchar(128) DEFAULT NULL COMMENT 'Nama Materi',
  `category` varchar(128) DEFAULT NULL COMMENT 'Category',
  `deskripsi` varchar(128) NOT NULL COMMENT 'Deskripsi',
  `tanggal` datetime(6) NOT NULL COMMENT 'Tanggal',
  `path` varchar(200) NOT NULL COMMENT 'Path',
  PRIMARY KEY (`materi_id`),
  KEY `FK_jenis` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `materi` */

insert into `materi` values 
(2,'Johannes','Buku','sa','2016-01-04 00:00:00.000000','/arsip/Johannes.pdf'),
(4,'Fright.Night.2011.BluRayRip.sebuah-dongeng.blogspot.com.mkv','Video','Final Drest','2016-01-05 00:00:00.000000','/arsip/Fright.Night.2011.BluRayRip.sebuah-dongeng.blogspot.com.mkv'),
(5,'Nonton Movie Film Predator Dark Ages (2015) Online Streaming Gratis Download Subtitle Indonesia.mp4','Video','Film Terfavorite 2015','2016-01-05 00:00:00.000000','/arsip/Nonton Movie Film Predator Dark Ages (2015) Online Streaming Gratis Download Subtitle Indonesia.mp4'),
(6,'Lagu Nommensen','Audio','Lagu terfavorit','2016-01-05 00:00:00.000000','/arsip/1.Viky - Nommensen.mp3');

/*Table structure for table `materi_terfavorit` */

DROP TABLE IF EXISTS `materi_terfavorit`;

CREATE TABLE `materi_terfavorit` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `materi_id` int(11) DEFAULT NULL COMMENT 'Materi ID',
  `category_id` int(11) DEFAULT NULL COMMENT 'Category ID',
  PRIMARY KEY (`id`),
  KEY `FK_materi` (`materi_id`),
  CONSTRAINT `FK_materi` FOREIGN KEY (`materi_id`) REFERENCES `materi` (`materi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `materi_terfavorit` */

/*Table structure for table `member` */

DROP TABLE IF EXISTS `member`;

CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `nama` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `alamat` varchar(128) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `account_id` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `member` */

insert into `member` values 
(9,35,'johannes','johannes@del.ac.id','M','doloksanggul','2016-01-04'),
(10,36,'edu','edu@del.ac.id','M','siantar','2016-01-04'),
(11,37,'anita','anita','F','Medan','2016-01-06'),
(12,38,'yosua','yosua@gmail.com','M','Binjai','2016-01-06'),
(13,39,'anggi','anggifrecelia@gmail.com','F','jalan gagak','2017-05-26');
