/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Imple;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Category;
import perpustakaan_digital.Interf.KategoryInterf;

/**
 *
 * @author Kelompok 10
 */
public class KategoryImple implements KategoryInterf
{
    
    private static DatabaseUtility dbUtil = new DatabaseUtility();
    
    @Override
    public void insert(String kat) throws SQLException {
        PreparedStatement ps=dbUtil.getConnection().prepareStatement("insert into category values(?)");
        ps.setString(1, kat);
        ps.executeUpdate();
    }
    
    @Override
    public List<Category> getAll() throws SQLException 
    {
        Statement st = dbUtil.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from category where category != \"Video\" and category != \"Audio\"");
        List<Category> list=new ArrayList<Category>();
        while(rs.next())
        {
            Category kt=new Category();
            kt.setCategory(rs.getString("category"));
            list.add(kt);
        }
        return list;
    }
    
    @Override
    public List<Category> getAllAudio() throws SQLException 
    {
        Statement st=DatabaseUtility.getConnection().createStatement();
        ResultSet rs=st.executeQuery("select * from category where category =  \"Audio\"");
        List<Category> list=new ArrayList<Category>();
        while(rs.next()){
            Category kt=new Category();
            kt.setCategory(rs.getString("category"));
            list.add(kt);
        }
        return list;
    }
    public List<Category> getAllVideo() throws SQLException {
        Statement st=DatabaseUtility.getConnection().createStatement();
        ResultSet rs=st.executeQuery("select * from category where category =  \"Video\"");
        List<Category> list=new ArrayList<Category>();
        while(rs.next()){
            Category kt=new Category();
            kt.setCategory(rs.getString("category"));
            list.add(kt);
        }
        return list;
    }
    
}

