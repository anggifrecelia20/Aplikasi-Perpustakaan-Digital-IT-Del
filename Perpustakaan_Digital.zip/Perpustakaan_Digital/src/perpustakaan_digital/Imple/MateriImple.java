/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Materi;
import perpustakaan_digital.Interf.MateriInterf;

/**
 *
 * @author Kelompok 10
 */
public class MateriImple implements MateriInterf{
    
    private static DatabaseUtility dbUtil = new DatabaseUtility();
    
    @Override
    public void delete(int id) throws SQLException 
    {
        PreparedStatement ps=dbUtil.getConnection().prepareStatement("delete from materi where materi_id = ? ");
        ps.setInt(1, id);
        ps.executeUpdate();
        ps.close();
    }
    
    @Override
    public void insert(Materi m) throws SQLException {
        PreparedStatement ps=DatabaseUtility.getConnection().prepareStatement("insert into materi (nama_materi,category,deskripsi,tanggal,path) values(?,?,?,CURDATE(),?)");
        ps.setString(1, m.getNama());
        ps.setString(2, m.getCategory());
        ps.setString(3, m.getDeskripsi());
        //ps.setString(4, m.getTanggal());
        ps.setString(4, m.getPath());
        ps.executeUpdate();
        
    }
    
    @Override
    public List<Materi> getAll() throws SQLException {
        Statement st=DatabaseUtility.getConnection().createStatement();
        ResultSet rs=st.executeQuery("select materi_id, nama_materi,category,deskripsi,tanggal,path from materi where category != \"Video\" and category != \"Audio\"");
        List<Materi> list=new ArrayList<Materi>();
        while(rs.next()){
            Materi m=new Materi();
            m.setM_ID(Integer.parseInt(rs.getString("materi_id")));
            m.setNama(rs.getString("nama_materi"));
            m.setCategory(rs.getString("category"));
            m.setDeskripsi(rs.getString("deskripsi"));
            m.setTanggal(rs.getDate("tanggal"));
            m.setPath(rs.getString("path"));
            list.add(m);
        }
        return list;
    }
    
    @Override
    public List<Materi> getAllVideo() throws SQLException {
        Statement st=DatabaseUtility.getConnection().createStatement();
        
        ResultSet rs=st.executeQuery("select nama_materi,category,deskripsi,tanggal,path from materi where category like \"VIDEO\"");
        List<Materi> list=new ArrayList<Materi>();
        while(rs.next()){
            Materi m=new Materi();
            m.setNama(rs.getString("nama_materi"));
            m.setCategory(rs.getString("category"));
            m.setDeskripsi(rs.getString("deskripsi"));
            m.setTanggal(rs.getDate("tanggal"));
            m.setPath(rs.getString("path"));
            list.add(m);
        }
        return list;
    }
    
    public List<Materi> getAllAudio() throws SQLException {
        Statement st=DatabaseUtility.getConnection().createStatement();
        
        ResultSet rs=st.executeQuery("select nama_materi,category,deskripsi,tanggal,path from materi where category like \"Audio\"");
        List<Materi> list=new ArrayList<Materi>();
        while(rs.next()){
            Materi m=new Materi();
            m.setNama(rs.getString("nama_materi"));
            m.setCategory(rs.getString("category"));
            m.setDeskripsi(rs.getString("deskripsi"));
            m.setTanggal(rs.getDate("tanggal"));
            m.setPath(rs.getString("path"));
            list.add(m);
        }
        return list;
    }
    
    public List<Materi> getKatNama(String nama, String kat) throws SQLException {
        PreparedStatement ps=DatabaseUtility.getConnection().prepareStatement("select nama_materi,category,deskripsi,tanggal,path from materi where nama_materi like ? and category=?");
        ps.setString(1, "%"+nama+"%");
        ps.setString(2, kat);
        ResultSet rs=ps.executeQuery();
        List<Materi> list=new ArrayList<Materi>();
        while(rs.next()){
            Materi m=new Materi();
            m.setNama(rs.getString("nama_materi"));
            m.setCategory(rs.getString("category"));
            m.setDeskripsi(rs.getString("deskripsi"));
            m.setTanggal(rs.getDate("tanggal"));
            m.setPath(rs.getString("path"));
            list.add(m);
        }
        return list;
    }
    
    @Override
    public List<Materi> getKatNamaVA(String nama) throws SQLException {
        PreparedStatement ps=DatabaseUtility.getConnection().prepareStatement("select nama_materi,category,deskripsi,tanggal,path from materi where nama_materi like ?");
        ps.setString(1, "%"+nama+"%");
        ResultSet rs=ps.executeQuery();
        List<Materi> list=new ArrayList<Materi>();
        while(rs.next()){
            Materi m=new Materi();
            m.setNama(rs.getString("nama_materi"));
            m.setCategory(rs.getString("category"));
            m.setDeskripsi(rs.getString("deskripsi"));
            m.setTanggal(rs.getDate("tanggal"));
            m.setPath(rs.getString("path"));
            list.add(m);
        }
        return list;
    }
}

