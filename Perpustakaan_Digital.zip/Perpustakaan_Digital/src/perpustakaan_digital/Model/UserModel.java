/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Account;


/**
 *
 * @author Kelompok 10
 */
public class UserModel {

//    DatabaseUtility con;
    Connection connection;

    public UserModel() {
        this.connection = new DatabaseUtility().getConnection();
    }

    public boolean isRegistered(String nama, String email, String sex, String alamat, String username, String password, String tanggal) {
        String account = "INSERT INTO account (username, password, last_login) VALUES(?,?,CURDATE())";

        PreparedStatement statementAccount = null;
        PreparedStatement statementMember = null;
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statementAccount = connection.prepareStatement(account);
            statementAccount.setString(1, username);
            statementAccount.setString(2, password);

            if (statementAccount.executeUpdate() == 1) {
                connection.commit();
                String accountID = "Select account_id from account where username = '" + username + "' AND password = '" + password + "'";
                statement = connection.prepareStatement(accountID);
                ResultSet rs = null;

                rs = statement.executeQuery();
                rs.next();
                int account_id = rs.getInt(1);
                Account a= new Account();
                a.setId(account_id);
                
                String member = "INSERT INTO member (account_id, nama,email, sex,  alamat,  tanggal) VALUES(?,?,?,?,?,CURDATE())";
                statementMember = connection.prepareStatement(member);
                statementMember.setInt(1, account_id);
                statementMember.setString(2, nama);
                statementMember.setString(3, email);
                statementMember.setString(4, sex);
                statementMember.setString(5, alamat);

                if (statementMember.executeUpdate() == 1) {
                    connection.commit();
                    JOptionPane.showMessageDialog(null, "Akun anda telah terdaftar di aplikasi, silahkan gunakan akun anda untuk login: ");

                    return true;
                }
                return true;

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error when insert your account \n Error: " + e.getMessage());
            try {
                connection.rollback();
                statementAccount.close();
            } catch (Exception ex) {
            }
            return false;
        } finally {
            if (statementAccount != null) {
                try {
                    statementAccount.close();
                } catch (Exception e) {
                }
            }
        }
        return false;
    }
    
    public boolean userType(){
        
        
        return false;
    }

    public boolean isLogin(String userName, String password) {
        PreparedStatement statement = null;
        PreparedStatement statementLogin = null;
        try {
            statement = connection.prepareStatement("SELECT * from account WHERE username=? AND `password`=?");
            statement.setString(1, userName);
            statement.setString(2, password);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                try {
                    connection.setAutoCommit(false);
                    String accountID = "UPDATE account SET last_login =CURDATE() where username = '" + userName + "' AND password = '" + password + "'";
                    statementLogin = connection.prepareStatement(accountID);            
                    if(statementLogin.executeUpdate() == 1){
                        connection.commit();
                        return true;
                    }
                    
                } catch (Exception e) {

                }
                return true;
            }
        } catch (Exception e) {
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
            } catch (Exception e) {
            }
        }
        return false;
    }

}
