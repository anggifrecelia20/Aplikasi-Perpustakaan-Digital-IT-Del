/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Category;

/**
 *
 * @author Kelompok 10
 */
public class CategoryModel{
    Connection connection;
    
    
    public CategoryModel() {
        connection = new DatabaseUtility().getConnection();
    }

    public Connection getConnection() {
        return connection;
    }
    
}
