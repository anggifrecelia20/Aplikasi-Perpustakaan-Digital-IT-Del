/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Category;
import perpustakaan_digital.Entity.Materi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import perpustakaan_digital.Views.FrameTambahMateri;


/**
 *
 * @author Kelompok 10
 */
public class MateriModel{

    Connection connection;
    Materi materi;
    Category category;
    JFileChooser choser = new JFileChooser();
    String dir, tujuan;
    File file;
    FrameTambahMateri ftm;
    

    public MateriModel() {
        connection = new DatabaseUtility().getConnection();
    }

    public Connection getConnection() {
        return connection;
    }
    


}
