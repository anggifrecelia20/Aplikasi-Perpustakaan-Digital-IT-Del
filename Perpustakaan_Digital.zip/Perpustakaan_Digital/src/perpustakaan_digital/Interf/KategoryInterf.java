/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Interf;

import java.sql.SQLException;
import java.util.List;
import perpustakaan_digital.Entity.Category;
import perpustakaan_digital.Entity.Materi;

/**
 *
 * @author Kelompok 10
 */
public interface KategoryInterf {
    void insert(String kat) throws SQLException;

    List<Category> getAll() throws SQLException;
    List<Category> getAllAudio() throws SQLException;
    List<Category> getAllVideo() throws SQLException;
     
}
