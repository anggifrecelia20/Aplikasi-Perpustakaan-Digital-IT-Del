/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Interf;

import java.sql.SQLException;
import java.util.List;
import perpustakaan_digital.Entity.Materi;

/**
 *
 * @author Kelompok 10
 */
public interface MateriInterf {
    void insert(Materi m)throws SQLException;
    public void delete(int id) throws SQLException;
    List<Materi> getAll() throws SQLException;
    public List<Materi> getAllVideo() throws SQLException;
    public List<Materi> getAllAudio() throws SQLException;
    List<Materi> getKatNamaVA(String nama) throws SQLException;

    List<Materi> getKatNama(String nama, String kat) throws SQLException;
    
}
