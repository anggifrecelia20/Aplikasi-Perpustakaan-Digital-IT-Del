/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import perpustakaan_digital.Database.DatabaseUtility;
import perpustakaan_digital.Entity.Category;
import perpustakaan_digital.Entity.Materi;
import perpustakaan_digital.Imple.KategoryImple;
import perpustakaan_digital.Imple.MateriImple;
import perpustakaan_digital.Interf.KategoryInterf;
import perpustakaan_digital.Interf.MateriInterf;

/**
 *
 * @author Kelompok 10
 */
public class FrameMateri extends javax.swing.JFrame 
{
    KategoryInterf kategori;
    MateriInterf materi;
    List<Materi> list = new ArrayList<Materi>();
    String dir, tujuan;
    MateriInterf materiInterf;
    Connection connection;

    public FrameMateri() {
        initComponents();
        setSize(700, 600);
        setLocationRelativeTo(null);
        setButton();
        materi = new MateriImple();
        kategori = new KategoryImple();
        dir = System.getProperty("user.dir");
       
        try 
        {
            loadKategori();
        } catch (SQLException ex) {
            Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            list = this.materi.getAll();
        } catch (SQLException ex) {
            Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
        }
        isiTable();

    }

    void loadKategori() throws SQLException 
    {
        textCategory.removeAllItems();
        for (Category kat : kategori.getAll()) {
            textCategory.addItem(kat.getCategory());
        }
    }

    void isiTable() {
        Object data[][] = new Object[list.size()][5];
        int x = 0;
        
        for (Materi bk : list) 
        {
            data[x][0] = bk.getM_ID();
            data[x][1] = bk.getNama();
            data[x][2] = bk.getCategory();
            data[x][3] = bk.getDeskripsi();
            data[x][4] = bk.getTanggal();
            x++;
        }
        String[] judul = {"Nama", "Kategori", "Deskripsi", "Tanggal"};
        tabel.setModel(new DefaultTableModel(data, judul));
        jScrollPane1.setViewportView(tabel);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        BAdd = new javax.swing.JButton();
        BOpen = new javax.swing.JButton();
        BKeluar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        textNama = new javax.swing.JTextField();
        textCategory = new javax.swing.JComboBox();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setForeground(java.awt.Color.blue);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("List Materi Perpustakaan Digital IT DEL ");

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabel);

        BAdd.setText("Tambah");
        BAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAddActionPerformed(evt);
            }
        });

        BOpen.setText("Buka");
        BOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOpenActionPerformed(evt);
            }
        });

        BKeluar.setBackground(new java.awt.Color(204, 204, 204));
        BKeluar.setText("Kembali");
        BKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BKeluarActionPerformed(evt);
            }
        });

        jLabel2.setText("Nama");

        jLabel4.setText("Kategori");

        textNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNamaActionPerformed(evt);
            }
        });
        textNama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textNamaKeyPressed(evt);
            }
        });

        textCategory.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        textCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textCategoryActionPerformed(evt);
            }
        });

        update.setText("Edit");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        delete.setText("Hapus");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 92, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(delete)
                        .addGap(18, 18, 18)
                        .addComponent(BOpen, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BKeluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(28, 28, 28)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textNama)
                            .addComponent(textCategory, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(150, 150, 150)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(textCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BOpen)
                    .addComponent(delete)
                    .addComponent(BAdd)
                    .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BKeluar))
                .addGap(40, 40, 40))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textNamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textNamaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNamaKeyPressed

    private void textCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textCategoryActionPerformed
      try {
            // TODO add your handling code here:
            this.list = this.materi.getKatNamaVA(textNama.getText());
            isiTable();
        } catch (SQLException ex) {
            Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }//GEN-LAST:event_textCategoryActionPerformed

    private void BKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BKeluarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BKeluarActionPerformed

    private void BOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOpenActionPerformed
        int row = tabel.getSelectedRow();
        if (row != -1) {
            try {
                // TODO add your handling code here:

                tujuan = dir.substring(0, dir.length() - 5) + list.get(row).getPath();
                //            File buka=new File(tujuan);
                Process p = Runtime.getRuntime().exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", tujuan});
                p.waitFor();
                //            cmds.add(String.format("gnome-open %s", tujuan));
                //     String subCmd = (exec) ? "exec" : "openURL";
                //     cmds.add(String.format("kfmclient "+subCmd+" %s", fileName));
                //            Runtime r = Runtime.getRuntime();
                //    String myScript =tujuan;
                //    String[] cmdArray = {"gnome-open", "-e", myScript + " ; le_exec"};
                //    r.exec(cmdArray).waitFor();
                //            String command= tujuan;
                //    Runtime rt = Runtime.getRuntime();
                //    Process pr = rt.exec(command);

            } catch (InterruptedException ex) {
                Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_BOpenActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        
    }//GEN-LAST:event_updateActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) tabel.getModel();
        int row = tabel.getSelectedRow();
        MateriImple mam = new MateriImple();
        try {
            if(row>=0)
            {
                mam.delete(list.get(row).getM_ID());
                dtm.removeRow(row);
            }    
            
        } catch (SQLException ex) {
            Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
        }
        isiTable();
        
    }//GEN-LAST:event_deleteActionPerformed

    private void BAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BAddActionPerformed

    private void textNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNamaActionPerformed
        
    }//GEN-LAST:event_textNamaActionPerformed

    private void setButton() {
        BAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                add();
            }
        });
//        BHapus.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                int row=tabel.getSelectedRow();
//                list.get(row).getM_ID();
//                DeleteMateri(row);
//            }
//        });
//        BOpen.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                open();
//            }
//        });
        BKeluar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                keluar();
            }
        });
    }

//    public void DeleteMateri(int id){
//        if(JOptionPane.showConfirmDialog(this, "Apakah anda yakin menghapus data ini?","Hapus data",
//                JOptionPane.YES_NO_CANCEL_OPTION)==JOptionPane.YES_OPTION){
//            try {
//                
//                    this.materiInterf.delete(id);
//                    JOptionPane.showMessageDialog(this, "Delete Materi buku sukses");
//                } catch (SQLException ex) {
//                    Logger.getLogger(FrameMateri.class.getName()).log(Level.SEVERE, null, ex);
//                    JOptionPane.showMessageDialog(this, "Delete Materi buku gagal");
//                }
//                
//        }
//    }
    public void add() {

        dispose();
        FrameTambahMateri ftm = new FrameTambahMateri();
        ftm.setVisible(true);
    }

    public void keluar() {
        dispose();
        FrameUtama fm = new FrameUtama();
        fm.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BAdd;
    private javax.swing.JButton BKeluar;
    private javax.swing.JButton BOpen;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabel;
    private javax.swing.JComboBox textCategory;
    private javax.swing.JTextField textNama;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
