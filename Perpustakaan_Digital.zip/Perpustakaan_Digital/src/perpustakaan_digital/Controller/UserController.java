/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Controller;

import javax.swing.JOptionPane;
import perpustakaan_digital.Model.UserModel;
import perpustakaan_digital.Views.FrameLogin;
import perpustakaan_digital.Views.FrameRegister;

/**
 *
 * @author Kelompok 10
 */
public class UserController {

    FrameLogin frameLogin;
    FrameRegister frameRegister;
    UserModel model;

    public void setModel(UserModel model) {
        this.model = model;
    }

    public UserController() {
    }

    public UserModel getModel() {
        return model;
    }
    public boolean registerMember(){
        if(frameRegister.getTextNama().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Nama Anda");
        }else if(frameRegister.getTextEmail().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Email Anda");
        }else if(frameRegister.getTextSex().getSelectedItem().equals("--pilih sex anda--")){
            JOptionPane.showMessageDialog(frameRegister, "Pilih jenis kelamin anda");
        }else if(frameRegister.getTextAlamat().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Alamat Anda");
        }else if(frameRegister.getTextUsername().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Username Anda");
        }else if(frameRegister.getTextPassword().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Password Anda");
        }else if(frameRegister.getTextTanggal().getText().equals("")){
            JOptionPane.showMessageDialog(frameRegister, "Masukan Tanggal Register Anda");
        }else{
            String nama = frameRegister.getTextNama().getText();
            String email = frameRegister.getTextEmail().getText();
            String sex = frameRegister.getTextSex().getSelectedItem().toString();
            String alamat = frameRegister.getTextAlamat().getText();
            String username = frameRegister.getTextUsername().getText();
            String password = frameRegister.getTextPassword().getText();
            String tanggal = frameRegister.getTextTanggal().getText();
            if(model.isRegistered(nama, email,sex, alamat, username, password, tanggal)){
                return true;
            }else{
                JOptionPane.showMessageDialog(frameRegister, "ada yang error ketika menginsert data anda, \n "
                        + "silahkan diulangi lagi ");
            }
        }
        return false;
    }

    public boolean login() {
        if (frameLogin.getTextUserName().getText().equals("")) {
            JOptionPane.showMessageDialog(frameLogin, "Masukan userName Anda");
            frameLogin.getTextUserName().requestFocus();
        } else if (frameLogin.getTextPassword().getText().equals("")) {
            JOptionPane.showMessageDialog(frameLogin, "Masukan Password Anda");
            frameLogin.getTextPassword().requestFocus();
        } else {
            String userName = frameLogin.getTextUserName().getText();
            String password = frameLogin.getTextPassword().getText();

            if (model.isLogin(userName, password)) {
                return true;
            } else {
                JOptionPane.showMessageDialog(frameLogin, "Username atau Password anda salah, \n "
                        + "pastikan anda ketik username dan password dengan benar ");
            }
        }
        return false;
    }

    public void setFrameLogin(FrameLogin frameLogin) {
        this.frameLogin = frameLogin;
    }
    public void setFrameRegister(FrameRegister frameRegister) {
        this.frameRegister = frameRegister;
    }

}
