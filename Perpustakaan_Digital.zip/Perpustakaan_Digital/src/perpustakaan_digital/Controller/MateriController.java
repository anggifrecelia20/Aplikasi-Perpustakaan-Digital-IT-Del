/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Controller;

import perpustakaan_digital.Entity.Materi;
import perpustakaan_digital.Model.MateriModel;
import perpustakaan_digital.Views.FrameMateri;
import perpustakaan_digital.Views.FrameTambahMateri;

/**
 *
 * @author Kelompok 10
 */
public class MateriController {
    FrameMateri frameMateri;
    FrameTambahMateri ftm;
//    FrameMateri fm;
    Materi materi;
    MateriModel model;
    
    public MateriController() { }

    public void setModel(MateriModel model) {
        this.model = model;
    }
    public MateriController(FrameMateri frameMateri, MateriModel model) {
        this.frameMateri = frameMateri; 
        this.model = model;
    }

    public MateriModel getModel() {
        return model;
    }
    
    public FrameMateri getBukuView() {
        return frameMateri;
    }
    
    public void setFrameTambahMateri(FrameTambahMateri ftm) {
        this.ftm = ftm;
    }
    public void setFrameMateri(FrameMateri fm) {
        this.frameMateri = fm;
    }
}
