/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

import java.util.Date;

/**
 *
 * @author Kelompok 10
 */
public class Materi {
    //attribute kelas materi
    public int M_ID;
    private String nama;
    private String kategory;
    private String deskripsi;
    private Date tanggal;
    private String path;
    
    //costructur materi no parameter
    public Materi(){
    
    }
    //costructur materi with parameter
    public Materi(int _M_ID, String _nama, String _kategory, String _deskripsi, Date _tanggal, String _path){
        this.M_ID = _M_ID;
        this.nama = _nama;
        this.kategory = _kategory;
        this.deskripsi = _deskripsi;
        this.tanggal = _tanggal;
        this.path = _path;
    }
    //setter
    public void setM_ID(int _M_ID){
        this.M_ID = _M_ID;
    }
    public void setNama(String _nama){
        this.nama = _nama;
    }
    public void setCategory(String _kategory){
        this.kategory = _kategory;
    }
    public void setTanggal(Date _tanggal){
        this.tanggal = _tanggal;
    }
    public void setDeskripsi(String _deskripsi){
        this.deskripsi = _deskripsi;
    }
   
    public void setPath(String _path){
        this.path = _path;
    }
    //getter
    public int getM_ID(){
        return M_ID ;
    }
    public String getNama(){
        return nama ;
    }
    public String getCategory(){
        return kategory ;
    }
    public Date getTanggal(){
        return tanggal ;
    }
    public String getDeskripsi(){
        return deskripsi ;
    }
    
    public String getPath(){
        return path ;
    }
    
}
