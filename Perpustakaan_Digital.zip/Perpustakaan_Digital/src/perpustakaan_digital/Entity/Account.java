/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

import java.util.Date;

/**
 *
 * @author Kelompok 10
 */
public class Account {
    
    private int ID;
    private String username;
    private String password;
    private Date last_login;
    
    //constructor account no parameter
    public void Account(){
    }
    //constructor account with parameter
    public void Account(int _ID, String _username, String _password, Date _last_login){
        this.ID = _ID;
        this.username = _username;
        this.password  = _password;
        this.last_login = _last_login;
    }
    
    //setter
    public void setId(int _ID){
        this.ID = _ID;
    }
    public void setUsername(String _username){
        this.username = _username;
    }
    public void setPassword(String _password){
        this.password= _password;
    }
    public void setLast_Login(Date _last_login){
        this.last_login = _last_login;
    }
    
    //getter
    public int getId(){
        return ID;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public Date getLast_Login(){
        return last_login;
    }
}
