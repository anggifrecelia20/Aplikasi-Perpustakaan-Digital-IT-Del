/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

/**
 *
 * @author Kelompok 10
 */
public class Category {
    private String category;
    
    public void Category(){}
    
    public void Category(String _category){
        this.category = _category; 
    }
    
    //setter
    
    public void setCategory(String _category){
        this.category = _category;
    }
    //getter
    
    public String getCategory(){
        return category;
    }
}
