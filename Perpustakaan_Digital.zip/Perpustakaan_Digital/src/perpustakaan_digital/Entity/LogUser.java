/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

import java.util.Date;

/**
 *
 * @author Kelompok 10
 */
public class LogUser {
    
    private int id;
    private int account_id;
    private Date last_login;
    private String work;
    
    //constructor loguser no parameter
    public void LogUser(){}
    //constructor loguser with parameter
    public void LogUser(int _id, int _account_id, Date _last_login, String _work){
        this.id = _id;
        this.account_id = _account_id;
        this.last_login = _last_login;
        this.work = _work;
    }
    //setter
    public void setId(int _id){
        this.id =_id;
    }
    
    public void setAccount_id(int _account_id){
        this.account_id = _account_id;
    }
    public void setLast_Login(Date _last_login){
        this.last_login = _last_login;
    }
    public void setWork(String _work){
        this.work  = _work;
    }
    //getter
    public int getId(){
        return id;
    }
    public int getAccount_id(){
        return account_id;
    }
    public Date getLast_Login(){
        return last_login;
    }
    public String getWork(){
        return work;
    }
}
