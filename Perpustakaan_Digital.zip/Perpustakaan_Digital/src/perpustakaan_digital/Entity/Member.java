/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

/**
 *
 * @author Kelompok 10
 */
public class Member {
    
    private int id;
    private int account_id;
    private String nama;
    private String email;
    private String sex;
    private String alamat;
    
    public Member(){}
    
    public Member(int _id, int _account_id, String _nama, String _email, String _sex, String _alamat){
        this.id = _id;
        this.account_id = _account_id;
        this.nama = _nama;
        this.email = _email;
        this.sex = _sex;
        this.alamat = _alamat;
    }
    
    //setter
    public void setId(int _id){
        this.id = _id;
    }
    public void setAccount_id(int _account_id){
        this.account_id = _account_id;
    }
    public void setNama(String _nama){
        this.nama = _nama;
    }
    public void setEmail(String _email){
        this.email = _email;
    }
    public void setSex(String _sex){
        this.sex = _sex;
    }
    public void setAlamat(String _alamat){
        this.alamat = _alamat;
    }
    
    //getter
    public int getId(){
        return id;
    }
    public int getAccount_id(){
        return account_id;
    }
    public String getNama(){
        return nama;
    }
    public String getEmail(){
        return email;
    }
    public String getSex(){
        return sex;
    }
    public String getAlamat(){
        return alamat;
    }
    
    public Object getObject(int index) {
        switch(index){
            case 0: return id;
            case 1: return account_id;
            case 2: return nama;
            case 3: return email;
            case 4: return sex;
            case 5: return alamat;
            default: return null;
        }
    }
    
}
