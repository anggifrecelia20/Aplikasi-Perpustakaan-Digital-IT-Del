/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan_digital.Entity;

import java.util.Date;

/**
 *
 * @author Kelompok 10
 */
public class Audio {

    private int id;
    private String nama;
    private Date tanggal;
    private String path;
    
    public void Audio(){}
    
    public void Audio(int _id,String _nama, Date _tanggal, String _path){
        this.id = _id;
        this.nama = _nama;
        this.tanggal = _tanggal;
        this.path = _path;
    }
    
    //setter
    public void setId(int _id){
        this.id = _id;
    }
    public void setNama(String _nama){
        this.nama = _nama;
    }
    public void setTanggal(Date _tanggal){
        this.tanggal  = _tanggal;
    }
    public void setPath(String _path){
        this.path = _path;
    }
    
    //getter
    public int getId(){
        return id;
    }
    public String getNama(){
        return nama;
    }
    public Date getTanggal(){
        return tanggal;
    }
    public String getPath(){
        return path;
    }
}
